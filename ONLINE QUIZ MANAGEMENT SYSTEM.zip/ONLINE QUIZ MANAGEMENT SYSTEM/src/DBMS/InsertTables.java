package DBMS;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
//1602-19-737-113 C. Srilatha
@SuppressWarnings("serial")
public class InsertTables extends Frame implements ActionListener 
{
	MenuBar mb;
	MenuItem m5,m6,m7,m8,m9,m10,m11,m12,m13,m14,m15,m16,m17,m18,m19,m20;
	
	Menu register,login,question,score;
	Button insertButton,submit;
	

	TextField registeremidText, registernumberText, registerusernameText;
	TextField loginemidText, loginpasswordText;
	TextField qidText,qnText,option1Text,option2Text,option3Text,option4Text;
	TextField scoreqidText,emidText,scoredText,scoreText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	
	
	//For updates
	Button modify;
	List registerlist,loginlist,scorelist;// menuList,ordersList,restaurantList,customerList;
	
	ResultSet rs;
	
	//For delete
	Button deleteRowButton;
	
	public InsertTables()
	{
		try 
		{
			Class.forName ("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB ();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","srilatha");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildFrame()
	{
		//Basic Frame Properties
		setTitle("Online Quiz Management System");
		setSize(500, 600);
		setVisible(true);
		
		//menubar
		mb = new MenuBar();
		setMenuBar(mb);  
        setSize(550,500);  
        setLayout(null);  
        setVisible(true);
        
        
        //register
        register=new Menu("Register"); 
        m5=new MenuItem("Insert Register");
        m6=new MenuItem("Update Register");
        m7=new MenuItem("Delete Register");
        m8=new MenuItem("View Register");
        
        register.add(m5);
        register.add(m6);
        register.add(m7);
        register.add(m8);
        
        mb.add(register);
        
       // login
        login=new Menu("Login");  
        m9=new MenuItem("Insert login");
        m10=new MenuItem("Update login");
        m11=new MenuItem("Delete login");
        m12=new MenuItem("View login");
       
        login.add(m9);
        login.add(m10);
        login.add(m11);
        login.add(m12);
        
        mb.add(login);
        
        //QUIZ QUESTION
        question=new Menu("QUIZ");
        m13=new MenuItem("Insert Question Details");
        m14=new MenuItem("Update Question Details");
        m15=new MenuItem("Delete Question Details");
        m16=new MenuItem("View Question Details");
        
        question.add(m13);
        question.add(m14);
        question.add(m15);
        question.add(m16);
        
        mb.add(question);
        
        //SCORE
        score=new Menu("Score");
        m17=new MenuItem("Insert Score Details");
        m18=new MenuItem("Update Score Details");
        m19=new MenuItem("Delete Score Details");
        m20=new MenuItem("View Score Details");
        
        score.add(m13);
        score.add(m14);
        score.add(m15);
        score.add(m16);
        
        mb.add(score);
       
        m5.addActionListener(this);
        m6.addActionListener(this);
        m7.addActionListener(this);
        m8.addActionListener(this);
        m9.addActionListener(this);
        m10.addActionListener(this);
        m11.addActionListener(this);
        m12.addActionListener(this);
        m13.addActionListener(this);
        m14.addActionListener(this);
        m15.addActionListener(this);
        m16.addActionListener(this);
        m17.addActionListener(this);
        m18.addActionListener(this);
        m19.addActionListener(this);
        m20.addActionListener(this);
        
        }
	
	public void actionPerformed(ActionEvent ae)
	{
		String arg = ae.getActionCommand();
		if(arg.equals("Insert Register"))
			this.buildGUIRegister();
		if(arg.equals("Update Register"))
			this.updateRegisterGUI();
		if(arg.equals("Delete Register"))
			this.deleteGUIregister();
		if(arg.equals("View Register"))
			this.viewRegisterGUI();	
		if(arg.equals("Insert Login"))
			this.buildGUILogin();
		if(arg.equals("Update Login"))
			this.updateLoginGUI();
		if(arg.equals("Delete Login"))
			this.deleteGUIlogin();
		if(arg.equals("View login"))
			this.viewLoginGUI();	
		if(arg.equals("Insert Questions Details"))
			this.buildGUIQuestion();
		if(arg.equals("Update Questions Details"))
			this.updateQuestionGUI();
		if(arg.equals("Delete Questions Details"))
			this.deleteGUIQuestion();
		if(arg.equals("View Questions Details"))
			this.viewQuestionGUI();
		if(arg.equals("Insert Score"))
		    this.buildGUIScore();
	    if(arg.equals("Update Score"))
		    this.updateScoreGUI();
	    if(arg.equals("Delete Score"))
		    this.deleteGUIScore();
	    if(arg.equals("View Score"))
		    this.viewScoreGUI();	
	}
	

	
	public void buildGUIRegister() 
	{	 	
		removeAll();
		//Handle Insert Account Button
		insertButton = new Button("Submit");
		insertButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{		  
				  String query= "INSERT INTO register VALUES('" + registeremidText.getText() + "', " + "'" + registernumberText.getText() + "'," + registerusernameText.getText() + "')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});	
		registeremidText = new TextField(15);
		registernumberText = new TextField(15);
		registerusernameText = new TextField(15);


		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Register EMID:"));
		first.add(registeremidText);
		first.add(new Label("Register Number:"));
		first.add(registernumberText);
		first.add(new Label("Register username:"));
		first.add(registerusernameText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertButton);
        		second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		//setLayout(null);

		add(first);
		add(second);
		add(third);
		
		setLayout(new FlowLayout());
		setVisible(true);
	    
	
	}
	public void buildGUILogin() 
	{	
		removeAll();	
		loginlist = new List(6);
		loadLogin();
		add(loginlist);
		
		//When a list item is selected populate the text fields
		loginlist.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM login");
					while (rs.next()) 
					{
						if (rs.getString("loginemid").equals(loginlist.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						loginemidText.setText(rs.getString("loginemid"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Insert Account Button
		insertButton = new Button("Submit");
		insertButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{		  
					String query= "INSERT INTO Orders VALUES('" + loginemidText.getText() + "', " + "'" + loginpasswordText.getText()/* + "'," + orderpriceText.getText() + ",'" + ordertypeText.getText()*/ + "')";
					  int i = statement.executeUpdate(query);
					  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});	
		loginemidText = new TextField(15);
		loginemidText.setEditable(false);
		loginpasswordText = new TextField(15);
		

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Login EMID:"));
		first.add(loginemidText);
		first.add(new Label("Login password:"));
		first.add(loginpasswordText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertButton);
        		second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		//setLayout(null);
		

		add(first);
		add(second);
		add(third);
		
		setLayout(new FlowLayout());
		setVisible(true);
	    

	}
	
	
	public void buildGUIQuestion()
	{
		removeAll();
		submit = new Button("Submit");
		submit.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{		  
				  String query= "INSERT INTO Question VALUES('" + qidText.getText() + "','" + qnText.getText() + "'," + option1Text.getText() + ",'" + option2Text.getText() + "','" + option3Text.getText() +"'.'"+ option4Text.getText()+ "')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nCreated " + i + " QUESTION");
				}
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});
		
		qidText = new TextField(20);
	    qidText.setEditable(false);
	    qnText = new TextField(20);
		
		option1Text = new TextField(20);
		option2Text = new TextField(20);
		option3Text = new TextField(20);
		option4Text = new TextField(20);

		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label("QUESTION ID :"));
		first.add(qidText);
		first.add(new Label("QUESTION DESCRIPTION:"));
		first.add(qnText);
		first.add(new Label("OPTION1:"));
		first.add(option1Text);
		first.add(new Label("OPTION 2"));
		first.add(option2Text);
		first.add(new Label("OPTION3"));
		first.add(option3Text);
		first.add(new Label("OPTION4"));
		first.add(option4Text);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		
		add(second);
		add(third);
	    
		setLayout(new FlowLayout());
		setVisible(true);
		
	
		
	}
	
	public void buildGUIScore() 
	{	 	
		removeAll();
		//Handle Insert Account Button
		insertButton = new Button("Submit");
		insertButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{		  
				  String query= "INSERT INTO score VALUES('" + scoreqidText.getText() + "', '"  + emidText.getText() + "'," + scoredText.getText() +"','"+scoreText.getText() "')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});	
		scoreqidText = new TextField(15);
		emidText = new TextField(15);
		scoredText = new TextField(15);
	    scoreText= new TextField(15);

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("QID:"));
		first.add(qidText);
		first.add(new Label("EMID:"));
		first.add(emidText);
		first.add(new Label("Scored:"));
		first.add(scoredText);
		first.add(new Label("Score:"));
		first.add(scoreText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertButton);
        		second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		//setLayout(null);

		add(first);
		add(second);
		add(third);
		
		setLayout(new FlowLayout());
		setVisible(true);
	    
	
	}
		
	private void loadRegister() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM register");
		  while (rs.next()) 
		  {
			  registerlist.add(rs.getString("registeremid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	public void updateRegisterGUI() 
	{	
		removeAll();
		registerlist = new List(6);
		loadRegister();
		add(registerlist);
		
		//When a list item is selected populate the text fields
		registerlist.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM register");
							while (rs.next()) 
					{
						if (rs.getString("registeremid").equals(registerlist.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						registeremidText.setText(rs.getString("registeremid"));
						registernumberText.setText(rs.getString("registernumber"));
						registerusernameText.setText(rs.getString("registerusername"));
						//registertypeText.setText(rs.getString("registertype"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Update Menu Button
		modify = new Button("Update Register");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE register "
					+ "SET registerusername=" + registerusernameText.getText()  
					+ " WHERE registeremid ='" + registerlist.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					registerlist.removeAll();
					loadRegister();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		registeremidText = new TextField(15);
		registeremidText.setEditable(false);
		registernumberText = new TextField(15);
		registernumberText.setEditable(false);
		registerusernameText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Register EMID:"));
		first.add(registeremidText);
		first.add(new Label("Register number:"));
		first.add(registernumberText);
		first.add(new Label("Register username:"));
		first.add(registerusernameText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	
	public void deleteGUIregister()
	{
		removeAll();
	    registerlist = new List(10);
		loadRegister();
		add(registerlist);
		
		//When a list item is selected populate the text fields
		registerlist.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM register");
					while (rs.next()) 
					{
						if (rs.getString("registeremid").equals(registerlist.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						registeremidText.setText(rs.getString("registeremid"));
						registernumberText.setText(rs.getString("registernumber"));
						registerusernameText.setText(rs.getString("registerusername"));
		
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});
	    
		//Handle Delete restaurant Button
		deleteRowButton = new Button("Delete Row");
		deleteRowButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM register WHERE registeremid = '" + registerlist.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					registeremidText.setText(null);
					registernumberText.setText(null);
					registerusernameText.setText(null);
					registerlist.removeAll();
					loadRegister();
				} 
				catch (SQLException deleteException) 
				{
					displaySQLErrors(deleteException);
				}
			}
		});
		
		registeremidText = new TextField(15);
		registernumberText = new TextField(15);
		registerusernameText = new TextField(15);

		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		
		registeremidText.setEditable(false);
		registernumberText.setEditable(false);
		registerusernameText.setEditable(false);
		
	

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Register EMID:"));
		first.add(registeremidText);
		first.add(new Label("Register Number:"));
		first.add(registernumberText);
		first.add(new Label("Register username:"));
		first.add(registerusernameText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteRowButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    

		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	
	
	private void loadLogin() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Login");
		  while (rs.next()) 
		  {
			  loginlist.add(rs.getString("loginemid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	public void updateLoginGUI() 
	{	
		removeAll();
		loginlist = new List(6);
		loadLogin();
		add(loginlist);
		
		//When a list item is selected populate the text fields
		loginlist.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM login");
					while (rs.next()) 
					{
						if (rs.getString("loginemid").equals(loginlist.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						loginemidText.setText(rs.getString("loginemid"));
						loginpasswordText.setText(rs.getString("loginpassword"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Update Menu Button
		modify = new Button("Modify");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE menu "
					+ "SET loginemid=" + loginemidText.getText()  
					+ " WHERE loginpassword = '" + loginlist.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					loginlist.removeAll();
					loadMenu();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		loginemidText = new TextField(15);
		loginemidText.setEditable(false);
		loginpasswordText = new TextField(15);
		loginpasswordText.setEditable(false);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Login EMID:"));
		first.add(loginemidText);
		first.add(new Label("Login password:"));
		first.add(loginpasswordText);
		
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
	
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	public void deleteGUIlogin()
	{
		removeAll();
	    loginlist = new List(10);
		loadLogin();
		add(loginlist);
		
		//When a list item is selected populate the text fields
		loginlist.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM login");
					while (rs.next()) 
					{
						if (rs.getString("orderid").equals(loginlist.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						loginemidText.setText(rs.getString("loginemid"));
						loginpasswordText.setText(rs.getString("loginpassword"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});
	    
		//Handle Delete orders Button
		deleteRowButton = new Button("Delete Row");
		deleteRowButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM orders WHERE loginemid= '" + loginlist.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					loginemidText.setText(null);
					loginpasswordText.setText(null);
					
					loginlist.removeAll();
					loadLogin();
				} 
				catch (SQLException deleteException) 
				{
					displaySQLErrors(deleteException);
				}
			}
		});
		
		loginemidText = new TextField(15);
		loginpasswordText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		
		loginemidText.setEditable(false);
		loginpasswordText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Login EMID:"));
		first.add(loginemidText);
		first.add(new Label("Login password:"));
		first.add(loginpasswordText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteRowButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    

		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	
	public void loadQuestion()
	{					   
			try 
			{
			  rs = statement.executeQuery("SELECT * FROM Question");
			  while (rs.next()) 
			  {
			  
				Questionlist.add(rs.getString("qid"));
			  }
			} 
			catch (SQLException e) 
			{ 
			  displaySQLErrors(e);
			}

	}

	public void updateQuestionGUI()
	{
		removeAll();
		QuestionList = new List(6);
        loadQuestion();
		add(Questionlist);
		
		//When a list item is selected populate the text fields
		questionList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Question");
					while (rs.next()) 
					{
						if (rs.getString("qid").equals(QuestionList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						qidText.setText(rs.getString("qid"));
						qnText.setText(rs.getString("qn"));
						option1Text.setText(rs.getString("option1"));
						option2Text.setText(rs.getString("option2"));
						option3Text.setText(rs.getString("option3"));
						option4Text.setText(rs.getString("option4"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Update Menu Button
		modify = new Button("Modify");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Question  SET qid='" + qidText.getText() + "',qn='" + qnText.getText() + "',option1='" + option1Text.getText() + "',option2='" + option2Text.getText()+ "',option3='"+option3Text.getText()+ "',option4='"+option4Text.getText()+WHERE qid = '" + QuestionList.getSelectedItem() + "' ");
					errorText.append("\nUpdated " + i + " rows successfully");
					questionList.removeAll();
					loadquestion();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		qidText = new TextField(20);
		qidText.setEditable(false);
		qnText = new TextField(20);
		
		option1Text = new TextField(20);
		option2Text = new TextField(20);
		option3Text = new TextField(20);
		option4Text = new TextField(20);

		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label("QID:"));
		first.add(qidText);
		first.add(new Label("QN:"));
		first.add(qnText);
		first.add(new Label("OPTION1:"));
		first.add(option1Text);
		first.add(new Label("OPTION2:"));
		first.add(option2Text);
		first.add(new Label("OPTION3:"));
		first.add(option3Text);
		first.add(new Label("OPTION4:"));
		first.add(option4Text);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		
		add(second);
		add(third);
	    
		setLayout(new FlowLayout());
		setVisible(true);
		
		
	}
	
	public void deleteGUIQuestion()
	{
			removeAll();
		    QuestionList = new List(10);
			loadQuestion();
			add(QuestionList);
			
			//When a list item is selected populate the text fields
			QuestionList.addItemListener(new ItemListener()
			{
				public void itemStateChanged(ItemEvent e) 
				{
					try 
					{
						rs = statement.executeQuery("SELECT * FROM question");
						while (rs.next()) 
						{
							if (rs.getString("qid").equals(QuestionList.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
							qidText.setText(rs.getString("qid"));
							qnText.setText(rs.getString("qn"));
							option1Text.setText(rs.getString("option1"));
							option2Text.setText(rs.getString("option2"));
							option3Text.setText(rs.getString("option3"));
							option4Text.setText(rs.getString("option4"));
						}
					} 
					catch (SQLException selectException) 
					{
						displaySQLErrors(selectException);
					}
				}
			});
		    
			//Handle Delete orders Button
			deleteRowButton = new Button("Delete");
			deleteRowButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{
						Statement statement = connection.createStatement();
						int i = statement.executeUpdate("DELETE FROM Question WHERE qid = '" + QuestionList.getSelectedItem()+"'");
						errorText.append("\nDeleted " + i + " rows successfully");
						qidText.setText(null);
						qnText.setText(null);
						option1Text.setText(null);
						option2Text.setText(null);
						option3Text.setText(null);
						option4Text.setText(null);
				        QuestionList.removeAll();
						loadQuestion();
					} 
					catch (SQLException deleteException) 
					{
						displaySQLErrors(deleteException);
					}
				}
			});
			
			

			qidText = new TextField(20);
			qidText.setEditable(false);
			qnText = new TextField(20);
			
			option1Text = new TextField(20);
			option2Text = new TextField(20);
			option3Text = new TextField(20);
			option4Text = new TextField(20);

			qidText.setEditable(false);
			qnText.setEditable(false);
			option1Text.setEditable(false);
			option2Text.setEditable(false);
			option3Text.setEditable(false);
			option4Text.setEditable(false);

			errorText = new TextArea(10, 40);
			errorText.setEditable(false);

			Panel first = new Panel();
			first.setLayout(new GridLayout(5, 2));
			first.add(new Label(" QID:"));
			first.add(qidText);
			first.add(new Label("QUESTION DESCRIPTION:"));
			first.add(qnText);
			first.add(new Label("OPTION1 :"));
			first.add(option1Text);
			first.add(new Label("OPTION2:"));
			first.add(option2Text);
			first.add(new Label("OPTION3:"));
			first.add(option3Text);
			first.add(new Label("OPTION4:"));
			first.add(option4Text);
			
			Panel second = new Panel(new GridLayout(4, 1));
			second.add(deleteRowButton);
			
			Panel third = new Panel();
			third.add(errorText);
			
			add(first);
			
			add(second);
			add(third);
		    
			setLayout(new FlowLayout());
			setVisible(true);
				
		
	}
	
	private void loadScore() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM score");
		  while (rs.next()) 
		  {
			  scorelist.add(rs.getString("qid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void updateScoreGUI() 
	{	
		removeAll();
		scorelist = new List(6);
		loadScore();
		add(scorelist);
		
		//When a list item is selected populate the text fields
		scorelist.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM score");
							while (rs.next()) 
					{
						if (rs.getString("qid").equals(scorelist.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
					    qidText.setText(rs.getString("qid"));
						emidText.setText(rs.getString("emid"));
						scoredText.setText(rs.getString("scored"));
						scoredText.setText(rs.getString("scored"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Update Menu Button
		modify = new Button("Update Score");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE score "
					+ "SET qid=" + scored.getText()  
					+ " WHERE emid ='" + scorelist.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					scorelist.removeAll();
					loadScore();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		qidText = new TextField(15);
		qidText.setEditable(false);
		emidText = new TextField(15);
		emidText.setEditable(false);
		scoredText = new TextField(15);
		scoreText = new TextField(15);


		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("QID:"));
		first.add(qidText);
		first.add(new Label("EMID:"));
		first.add(emidText);
		first.add(new Label("Scored:"));
		first.add(scoredText);
		first.add(new Label("Score:"));
		first.add(scoreText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	
	public void deleteGUIScore()
	{
		removeAll();
	    scorelist = new List(10);
		loadScore();
		add(scorelist);
		
		//When a list item is selected populate the text fields
		scorelist.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM score");
					while (rs.next()) 
					{
						if (rs.getString("qid").equals(scorelist.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						qidText.setText(rs.getString("qid"));
						emidText.setText(rs.getString("emid"));
						scoredText.setText(rs.getString("scored"));
						scoreText.setText(rs.getString("score"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});
	    
		//Handle Delete restaurant Button
		deleteRowButton = new Button("Delete Row");
		deleteRowButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM register WHERE qid = '" + scorelist.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					qidText.setText(null);
					emidText.setText(null);
					scoredText.setText(null);
	                scoreText.setText(null);
					scorelist.removeAll();
					loadScore();
				} 
				catch (SQLException deleteException) 
				{
					displaySQLErrors(deleteException);
				}
			}
		});
		
		qidText = new TextField(15);
		emidText = new TextField(15);
		scoredText = new TextField(15);
		scoreText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);
		
		qidText.setEditable(false);
		emidText.setEditable(false);
		scoredText.setEditable(false);
		scoreText.setEditable(false);
	

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("QID:"));
		first.add(qidText);
		first.add(new Label("EMID:"));
		first.add(emidText);
		first.add(new Label("Scored:"));
		first.add(scoredText);
		first.add(new Label("Score:"));
		first.add(scoreText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteRowButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    

		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	public void viewRegisterGUI() 
	{	
		removeAll();
		registerList = new List(6);
		loadRegister();
		add(registerList);
		
		//When a list item is selected populate the text fields
		registerList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM register");
					while (rs.next()) 
					{
						if (rs.getString("registeremid").equals(registerList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						registeremidText.setText(rs.getString("regsiteremid"));
						registernumberText.setText(rs.getString("registernumber"));
						registerusernameText.setText(rs.getString("registerusername"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Update Menu Button
		modify = new Button("Update Register");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE register "
					+ "SET registerusername=" + registerusernameText.getText()  
					+ " WHERE registeremid = '" + registerList.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					registerList.removeAll();
					loadRegister();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		registeremidText = new TextField(15);
		registeremidText.setEditable(false);
		registernumberText = new TextField(15);
		registernumberText.setEditable(false);
		registerusernameText = new TextField(15);
		registerusernameText.setEditable(false);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("EMID:"));
		first.add(registeremidText);
		first.add(new Label("Register Number:"));
		first.add(registernumberText);
		first.add(new Label("Register Username:"));
		first.add(registerusernameText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		//second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}


	
	public void viewScoreGUI() 
	{	
		removeAll();
		scorelist = new List(6);
		loadScore();
		add(scorelist);
		
		//When a list item is selected populate the text fields
		scorelist.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM score");
					while (rs.next()) 
					{
						if (rs.getString("qid").equals(scorelist.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						qidText.setText(rs.getString("QID"));
						emidText.setText(rs.getString("EMID"));
						scoredText.setText(rs.getString("Scored"));
						scoreText.setText(rs.getString("Score"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Update Menu Button
		modify = new Button("Update Register");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE score "
					+ "SET qid=" + scoredText.getText()  
					+ " WHERE emid = '" + scorelist.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					scorelist.removeAll();
					loadRegister();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		qidText = new TextField(15);
		qidText.setEditable(false);
		emidText = new TextField(15);
		emidText.setEditable(false);
		scoredText = new TextField(15);
		scoredText.setEditable(false);
		scoreText = new TextField(15);
		scoreText.setEditable(false);

		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("QID:"));
		first.add(qidText);
		first.add(new Label("EMID:"));
		first.add(emidText);
		first.add(new Label("Scored:"));
		first.add(scoredText);
		first.add(new Label("Score:"));
		first.add(scoreText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		//second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	public void viewLoginGUI() 
	{	
		removeAll();
		loginlist = new List(6);
		loadLogin();
		add(loginlist);
		
		//When a list item is selected populate the text fields
		loginlist.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM login");
					while (rs.next()) 
					{
						if (rs.getString("loginemid").equals(loginlist.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						loginemidText.setText(rs.getString("loginemid"));
						loginpasswordText.setText(rs.getString("loginpassword"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});	    
		//Handle Update Menu Button
		modify = new Button("Modify");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE menu "
					+ "SET loginpassword=" + loginpasswordText.getText()  
					+ " WHERE loginemid = '" + loginlist.getSelectedItem() + "'");
					errorText.append("\nUpdated " + i + " rows successfully");
					loginlist.removeAll();
					loadMenu();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		loginemidText = new TextField(15);
		loginemidText.setEditable(false);
		loginpasswordText = new TextField(15);
		loginpasswordText.setEditable(false);

		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Login EMIID:"));
		first.add(loginemidText);
		first.add(new Label("Login password:"));
		first.add(loginpasswordText);
		
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(modify);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
	
		//setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	public void viewQuestionGUI()
	{
		removeAll();
	    QuestionList = new List(10);
		loadQuestion();
		add(QuestionList);
		
		//When a list item is selected populate the text fields
		QuestionList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM question");
					while (rs.next()) 
					{
						if (rs.getString("QID").equals(QuestionList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						qidText.setText(rs.getString("QID"));
						qnText.setText(rs.getString("QN"));
						option1Text.setText(rs.getString("OPTION1"));
						option2Text.setText(rs.getString("OPTION2"));
						option3Text.setText(rs.getString("OPTION3"));
						option4Text.setText(rs.getString("OPTION4"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});
	    
		
		
		

		qidText = new TextField(20);
		qidText.setEditable(false);
		qnText = new TextField(20);
		
		option1Text = new TextField(20);
		option2Text = new TextField(20);
		option3Text = new TextField(20);
		option4Text = new TextField(20);

		qidText.setEditable(false);
		qnText.setEditable(false);
		option1Text.setEditable(false);
		option2Text.setEditable(false);
		option3Text.setEditable(false);
		option4Text.setEditable(false);

		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label(" QID:"));
		first.add(qidText);
		first.add(new Label("QN:"));
		first.add(qnText);
		first.add(new Label("OPTION1 :"));
		first.add(option1Text);
		first.add(new Label("OPTION2:"));
		first.add(option2Text);
		first.add(new Label("OPTION3:"));
		first.add(option3Text);
		first.add(new Label("OPTION4:"));
		first.add(option4Text);
		
		Panel second = new Panel(new GridLayout(4, 1));
		//second.add(deleteRowButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		
		add(second);
		add(third);
	    
		setLayout(new FlowLayout());
		setVisible(true);
		
		
		
	}
	public void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

public static void main(String[] arg) 
	{
		InsertTables it = new InsertTables();
		it.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		it.buildFrame();
	}
}